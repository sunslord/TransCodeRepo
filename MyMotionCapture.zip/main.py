# This is a sample Python script.

# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.

import socket
import time
import csv
import os
import pickle
import json
from bvh import Bvh

#     "Head":[
#         {"Name":"Head", "Parent":-1, "Location":[0.0, 0.0, 0.0],
#         "Rotation":[0.0, 0.0, 0.0, 1.0], "Scale":[0.0, 0.0, 0.0]}, # this is a example
#         ...
#         {"Name":"xxx", "Parent":int, "Location":[float, float, float],
#         "Rotation":[float, float, float, float], "Scale":[float, float, float]},
#     ]
#     "Property":[
#         {"Name":"EyeBlinkLeft", "Value":0.5}, # this is a example
#         ...
#         {"Name":"xxx", "Value":float},
#     ]

"""
Motion capture Socket Frame Format:
{
    "MyXXX":{
        "HeadName":["EyeBlinkLeft","xxx", ..., string]  # Head blend-shape name
        "SkeletonName":["Hips","xxx",...string]         # skeleton Names Array
        "SkeletonParent":[-1, 0, ..., int]              # skeleton Parents
        "HeadData":[float, ..., float]                  # Head blend-shape Per Frame data
        "SkeletonData":[float, ..., float]              # skeleton Bvh Per Frame data
    }
}
"""

boneHead = 52  # ARKIT BS is 52
bodySkeleton = 60  # Neuton Skeleton is 60
dataArray = {"MyFaceCap": {"HeadName": [],
                           "HeadData": [],
                           "SkeletonName": [],
                           "SkeletonParent": [],
                           "SkeletonData": []}}


def send_data(name_csv, name_bvh, fps):
    if not os.path.exists(name_csv) or not os.path.exists(name_bvh):
        print('file () or () does not exist'.format(name_csv).format(name_bvh))
        return False, None
    _headDataArray = []
    _skeletonDataArray = []
    _skeletonName = dataArray['MyFaceCap']["SkeletonName"]
    _skeletonParent = dataArray['MyFaceCap']["SkeletonParent"]
    with open(name_csv) as datafile:
        _csvReader = csv.reader(datafile)
        for i, row in enumerate(_csvReader):
            if i == 0:
                dataArray['MyFaceCap']["HeadName"] = row[2:-9]
                continue
            if boneHead == 52:
                faceBSParas = row[2:-9]
                _headDataArray.append(faceBSParas)
        datafile.close()
    with open(name_bvh) as datafile:
        _bvhReader = Bvh(datafile.read())
        _skeletonName.clear()
        _skeletonParent.clear()
        for name in _bvhReader.get_joints_names():
            _skeletonName.append(name)
            _skeletonParent.append(_bvhReader.joint_parent_index(name))
        _skeletonDataArray = _bvhReader.frames
        datafile.close()
    # send the data
    _frameNum = min(len(_skeletonDataArray), len(_headDataArray))
    for i in range(_frameNum):
        dataArray['MyFaceCap']["HeadData"] = _headDataArray[i]
        dataArray['MyFaceCap']["SkeletonData"] = _skeletonDataArray[i]
        s.sendto(bytes(json.dumps(dataArray), encoding="utf-8"), addr)
        time.sleep(1 / fps)


def send_mocap_json(name_csv, name_bvh, fps):
    if not os.path.exists(name_csv):
        print('file () does not exist'.format(name_csv))
        return False, None
    with open(name_csv) as datafile:
        _csvReader = csv.reader(datafile)
        _arrayProperty = dataArray['MyFaceCap']["Property"]
        _arrayBone = dataArray['MyFaceCap']["Bone"]
        _arrayBone = {"Name": "Head", "Parent": -1, "Location": [0.0, 0.0, 0.0],
                      "Rotation": [0.0, 0.0, 0.0, 1.0], "Scale": [0.0, 0.0, 0.0]}
        for i, row in enumerate(_csvReader):
            _arrayProperty.clear()
            if i == 0:
                faceBSNames = row[2:-9]
                continue
            if boneHead == 52:
                faceBSParas = row[2:-9]
            for l in range(52):
                _arrayProperty.append({"Name": faceBSNames[l], "Value": float(faceBSParas[l])})

            s.sendto(bytes(json.dumps(dataArray), encoding="utf-8"), addr)
            # _response, _adr = s.recvfrom(1024)
            # print(_response.decode())
            # print('send {:0>4d} line'.format(i))
            time.sleep(1 / fps)
        datafile.close()


def send_testbvh(name_bvh, fps):
    if not os.path.exists(name_bvh):
        print('file () does not exist'.format(name_bvh))
        return False, None
    with open(name_bvh) as datafile:
        line_list = [line for line in datafile]
        for line in line_list:
            dataArray['MyFaceCap']["TestData"].clear()
            dataArray['MyFaceCap']["TestData"] = [float(i) for i in line.split(' ')[:-2] if i.strip()]
            dataArray['MyFaceCap']["TestData"].append(float(0))
            s.sendto(bytes(json.dumps(dataArray), encoding="utf-8"), addr)
            time.sleep(1 / fps)
            print('send {} '.format(line))
        datafile.close()


# def send_test():
#     testdata = []
#     headBone = json()


# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    addr = ("127.0.0.1", 7004)
    # s.connect(addr)
    t = 0
    while 1:
        send_data('MySlate_5_SunslordiPhone_cal.csv', 'NeuronCatWheel.bvh', 60)
        print('send {:0>4d} line'.format(t))
        t = t + 1
    s.close()

# See PyCharm help at https://www.jetbrains.com/help/pycharm/
