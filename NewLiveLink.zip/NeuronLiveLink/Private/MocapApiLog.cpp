#include "MocapApiLog.h"

DEFINE_LOG_CATEGORY(LogMocapApi)

