// Copyright 2021 Noitom Technology Co., Ltd. All Rights Reserved.


#include "SubjectNameSetter.h"

// Add default functionality here for any ISubjectNameSetter functions that are not pure virtual.

