#include "MocapClient.h"
#include "MocapStructs.h"
#include "MocapAppManager.h"
#include "NeuronLiveLinkSource.h"
#include "Roles/LiveLinkTransformTypes.h"
#include "Roles/LiveLinkAnimationTypes.h"
#include "Misc/App.h"
// for test input data
#include "Common/UdpSocketBuilder.h"
#include "Sockets.h"
#include "SocketSubsystem.h"
#include "Json.h"


static TMap<FString, EMCBvhRotationOrder> OrderMap = {
    { TEXT("XYZ"), EMCBvhRotationOrder::XYZ },
    { TEXT("XZY"), EMCBvhRotationOrder::XZY },
    { TEXT("YXZ"), EMCBvhRotationOrder::YXZ },
    { TEXT("YZX"), EMCBvhRotationOrder::YZX },
    { TEXT("ZXY"), EMCBvhRotationOrder::ZXY },
    { TEXT("ZYZ"), EMCBvhRotationOrder::ZYX },
};

EMCBvhRotationOrder GetRotationOrderFromString(const FString& RotationOrder)
{
    EMCBvhRotationOrder* Order = OrderMap.Find(RotationOrder);
    if (Order != nullptr)
    {
        return *Order;
    }
    return EMCBvhRotationOrder::YXZ;
}

FQualifiedFrameTime GetTimecode(const FMocapTimeCode& tc)
{
    FTimecode timecode(tc.Hour, tc.Minute, tc.Second, tc.Frame, false);
    FFrameRate rate(tc.Rate, 1);
    return FQualifiedFrameTime(timecode, rate);
}

FMocapAppClient::FMocapAppClient(bool IsUDP, const FString& RemoteIP, int Port, const FString& RotationOrder, int RecvPort)
    : Thread(nullptr)
    , bRunning(true)
{
    Sett.Protocol = IsUDP? EMCAppProtocol::UDP: EMCAppProtocol::TCP;
    Sett.RemoteIP = RemoteIP;
    Sett.Port = Port;
    Sett.RecvPort = RecvPort;
    Sett.bvhDataFormat = EMCBvhDataFormat::Binary;
    Sett.BvhRotation = EMCBvhRotationOrder::YXZ;

#ifdef SAVEDATA
    outfp.open("dataParas.bvh", 'w');
#endif

#ifdef MYMOCAPTEST
#define RECV_BUFFER_SIZE 1024 * 1024
    FIPv4Address addr;
    FIPv4Address::Parse(RemoteIP, addr);
    Socket = nullptr;
    Socket = FUdpSocketBuilder(TEXT("MyMocapSOCKET"))
        .AsNonBlocking()
        .AsReusable()
        .BoundToAddress(addr)
        .BoundToPort(Port)
        .WithReceiveBufferSize(RECV_BUFFER_SIZE);

    RecvBuffer.SetNumUninitialized(RECV_BUFFER_SIZE);

    if ((Socket != nullptr) && (Socket->GetSocketType() == SOCKTYPE_Datagram))
    {
        SocketSubsystem = ISocketSubsystem::Get(PLATFORM_SOCKETSUBSYSTEM);
        Thread = FRunnableThread::Create(this, TEXT("MocapAppClient"));
    }
#else
    StartApplication();
#endif // MYMOCAPTEST
}

FMocapAppClient::~FMocapAppClient()
{
    bRunning = false;
    if (Thread)
    {
        Thread->Kill(true);
        Thread = nullptr;
    }
#ifdef MYMOCAPTEST
    if (Socket != nullptr)
    {
        Socket->Close();
        ISocketSubsystem::Get(PLATFORM_SOCKETSUBSYSTEM)->DestroySocket(Socket);
    }
#endif // MYMOCAPTEST

#ifdef SAVADATA
    outfp.close();
#endif
    Exit();
}

void FMocapAppClient::SetSource(TSharedPtr<FNeuronLiveLinkSource> Source)
{
    mSource = Source;
}

//~ Begin FRunnable interface
bool FMocapAppClient::Init()
{
    return App != nullptr;
}

uint32 FMocapAppClient::Run()
{
#ifdef MYMOCAPTEST
    TSharedRef<FInternetAddr> Sender = SocketSubsystem->CreateInternetAddr();
#endif // MYMOCAPTEST

    while (bRunning)
    {
#ifdef MYMOCAPTEST       
        TestData(Sender);
#else
        PollEvents();
#endif // MYMOCAPTEST 
        FPlatformProcess::Sleep(1.0f/60);
    }
    return 0;
}

void FMocapAppClient::Stop()
{
    bRunning = false;
}

void FMocapAppClient::Exit()
{
    if (bRunning)
    {
        Stop();
    }
#ifndef MYMOCAPTEST
    DestroyApplication();
#endif // !MYMOCAPTEST
}

//~ End FRunnable interface


bool FMocapAppClient::StartApplication()
{
    //check(App == nullptr);
    App = NewObject<UMocapApp>();
    App->AddToRoot();
    App->AppSettings = Sett;
    FMCRenderSetting RenderSettings;
    App->RenderSettings = RenderSettings;
    AppName = App->GetConnectionString();
    App->AppName = AppName;
    App->Connect();

    Thread = FRunnableThread::Create(this, TEXT("MocapAppClient"));
    return true;
}

void FMocapAppClient::DestroyApplication()
{
    if (App)
    {
        App->RemoveFromRoot();
        App->Disconnect();
    }
    App = nullptr;
    AppName = TEXT("");
}

void FMocapAppClient::PollEvents()
{
    if (App)
    {
        bool hasNewEvents = App->PollEvents();
        if (!hasNewEvents)
        {
            return;
        }
#ifdef SAVEDATA
        outfp << "\n";
#endif // SAVEDATA
        TSharedPtr<FNeuronLiveLinkSource> Source = mSource.Pin();
        if (Source)
        {
            FLiveLinkWorldTime WorldTime = FPlatformTime::Seconds();
            FQualifiedFrameTime QualifiedTime = FApp::GetCurrentFrameTime().Get(FQualifiedFrameTime());
            int64 Now = FDateTime::UtcNow().GetTicks();
            int64 ValidTickDur = ETimespan::TicksPerSecond;

            TArray<FString> Avatars;
            App->GetAllAvatarNames(Avatars);

            for (FString& AvatarName : Avatars)
            {
                const FMocapAvatar* Data = App->GetAvatarData(AvatarName);
                if (Data->ReceiveTicks + ValidTickDur < Now)
                {
                    continue;
                }

                const TArray<FName> PropertyNames({ FName(TEXT("WithDisplacement")) });;
                TArray<float> PropertyValues({ (float)(Data->HasLocalPositions[1]? 1.0: 0.0) });

                QualifiedTime = GetTimecode(Data->ReceiveTime);

                FLiveLinkFrameDataStruct Frame = FLiveLinkFrameDataStruct(FLiveLinkAnimationFrameData::StaticStruct());
                
                FLiveLinkBaseFrameData* BaseData = Frame.GetBaseData();
                BaseData->WorldTime = WorldTime;
                BaseData->MetaData.SceneTime = QualifiedTime;
                
                FLiveLinkAnimationFrameData& FrameData = *Frame.Cast<FLiveLinkAnimationFrameData>();
                FrameData.PropertyValues = PropertyValues;
                int Count = Data->BoneNames.Num();
                for (int i = 0; i < Count; ++i)
                {
                    FrameData.Transforms.Add(FTransform(Data->LocalRotation[i], Data->LocalPositions[i]));
#ifdef SAVEDATA
                    outfp << Data->LocalRotation[i].Euler()[0] << " "
                        << Data->LocalRotation[i].Euler()[1] << " "
                        << Data->LocalRotation[i].Euler()[2] << " ";
                    outfp << Data->LocalPositions[i].X << " "
                        << Data->LocalPositions[i].Y << " "
                        << Data->LocalPositions[i].Z << " ";
#endif // SAVEDATA
                }
                
                FName AvatarSubjectName = Data->Name;
                if (!FMocapAppManager::GetInstance().IsNameUsedByApp(AvatarSubjectName, App))
                {
                    AvatarSubjectName = FMocapAppManager::CombineNameWithAppName(AvatarName, App);
                }

                Source->PushAvatarFrameData(AvatarSubjectName, PropertyNames, Frame);
            }

            TArray<FString> Rigids;
            App->GetAllRigidBodyNames(Rigids);

            for (FString Name : Rigids)
            {
                const FMocapRigidBody* RigidData = App->GetRigidBody(Name);
                if (RigidData && (RigidData->ReceiveTicks+ValidTickDur>=Now))
                {
                    FName Subject = RigidData->Name;
                    if (!FMocapAppManager::GetInstance().IsNameUsedByApp(Subject, App))
                    {
                        Subject = FMocapAppManager::CombineNameWithAppName(Name, App);
                    }
                    
                    FLiveLinkFrameDataStruct Frame = FLiveLinkFrameDataStruct(FLiveLinkTransformFrameData::StaticStruct());
                    
                    FLiveLinkBaseFrameData* BaseData = Frame.GetBaseData();
                    BaseData->WorldTime = WorldTime;
                    BaseData->MetaData.SceneTime = QualifiedTime;

                    FLiveLinkTransformFrameData& TransformData = *Frame.Cast<FLiveLinkTransformFrameData>();
                    const FVector& P = RigidData->Position;
                    const FQuat& Q = RigidData->Rotation;
                    TransformData.Transform.SetLocation(P);
                    TransformData.Transform.SetRotation(Q);

                    Source->PushTrackerFrameData(Subject, Frame);
                }
            }

			TArray<FString> Trackers;
			App->GetAllTrackerNames(Trackers);

			for (FString Name : Trackers)
			{
				const FMocapTracker* TrackerData = App->GetTracker(Name);
				if (TrackerData && (TrackerData->ReceiveTicks + ValidTickDur >= Now))
				{
					FName Subject = TrackerData->Name;
					if (!FMocapAppManager::GetInstance().IsNameUsedByApp(Subject, App))
					{
						Subject = FMocapAppManager::CombineNameWithAppName(Name, App);
					}

					FLiveLinkFrameDataStruct Frame = FLiveLinkFrameDataStruct(FLiveLinkTransformFrameData::StaticStruct());

					FLiveLinkBaseFrameData* BaseData = Frame.GetBaseData();
					BaseData->WorldTime = WorldTime;
					BaseData->MetaData.SceneTime = QualifiedTime;

					FLiveLinkTransformFrameData& TransformData = *Frame.Cast<FLiveLinkTransformFrameData>();
					const FVector& P = TrackerData->Position;
					const FQuat& Q = TrackerData->Rotation;
					TransformData.Transform.SetLocation(P);
					TransformData.Transform.SetRotation(Q);

					Source->PushTrackerFrameData(Subject, Frame);
				}
			}
        }
    }
}

#ifdef MYMOCAPTEST

void FMocapAppClient::TestData(TSharedRef<FInternetAddr>& Sender)
{
    if (Socket->Wait(ESocketWaitConditions::WaitForRead, FTimespan::FromMilliseconds(100)))
    {
        uint32 Size;
#ifdef SAVEDATA
        outfp << "\n";
#endif // SAVEDATA

        while (Socket->HasPendingData(Size))
        {
            int32 Read = 0;

            if (Socket->RecvFrom(RecvBuffer.GetData(), RecvBuffer.Num(), Read, *Sender))
            {
                if (Read > 0)
                {
                    TSharedPtr<TArray<uint8>, ESPMode::ThreadSafe> ReceivedData = MakeShareable(new TArray<uint8>());
                    ReceivedData->SetNumUninitialized(Read);
                    memcpy(ReceivedData->GetData(), RecvBuffer.GetData(), Read);
                    HandleReceivedData(ReceivedData);
                }
            }
        }
    }
}

void FMocapAppClient::HandleReceivedData(TSharedPtr<TArray<uint8>, ESPMode::ThreadSafe> ReceivedData)
{
    FString JsonString;
    JsonString.Empty(ReceivedData->Num());
    for (uint8& Byte : *ReceivedData.Get())
    {
        JsonString += TCHAR(Byte);
    }
    TSharedPtr<FJsonObject> JsonObject;
    TSharedRef<TJsonReader<>> Reader = TJsonReaderFactory<>::Create(JsonString);

    if (FJsonSerializer::Deserialize(Reader, JsonObject))
    {
        FLiveLinkFrameDataStruct Frame = FLiveLinkFrameDataStruct(FLiveLinkAnimationFrameData::StaticStruct());
        FLiveLinkAnimationFrameData& FrameData = *Frame.Cast<FLiveLinkAnimationFrameData>();
        FLiveLinkStaticDataStruct Static = FLiveLinkStaticDataStruct(FLiveLinkSkeletonStaticData::StaticStruct());
        FLiveLinkSkeletonStaticData& StaticData = *Static.Cast<FLiveLinkSkeletonStaticData>();

        for (TPair<FString, TSharedPtr<FJsonValue>>& JsonField : JsonObject->Values)
        {
            const TSharedPtr<FJsonObject> MyJsonObject = JsonField.Value->AsObject();
            const FName Subject(JsonField.Key);

            const TArray<TSharedPtr<FJsonValue>>* SkeletonName;
            if (MyJsonObject->TryGetArrayField(TEXT("SkeletonName"), SkeletonName))
            {
                StaticData.BoneNames.SetNumUninitialized(SkeletonName->Num());
                for (int i = 0; i < SkeletonName->Num(); i++)
                {
                    StaticData.BoneNames[i] = FName(*(*SkeletonName)[i]->AsString());
                }
            }

            const TArray<TSharedPtr<FJsonValue>>* SkeletonParent;
            if (MyJsonObject->TryGetArrayField(TEXT("SkeletonParent"), SkeletonParent))
            {
                StaticData.BoneParents.SetNumUninitialized(SkeletonParent->Num());
                StaticData.PropertyNames = TArray<FName>({ FName(TEXT("WithDisplacement")) });
                for (int i = 0; i < SkeletonParent->Num(); i++)
                {
                    StaticData.BoneParents[i] = static_cast<int32>(FMath::RoundHalfFromZero((*SkeletonParent)[i]->AsNumber()));
                }
            }

            const TArray<TSharedPtr<FJsonValue>>* SkeletonParameterArray;
            if (MyJsonObject->TryGetArrayField(TEXT("SkeletonData"), SkeletonParameterArray))
            {
                FLiveLinkBaseFrameData* BaseData = Frame.GetBaseData();
                BaseData->WorldTime = FLiveLinkWorldTime();
                BaseData->MetaData.SceneTime = FQualifiedFrameTime();
                FrameData.PropertyValues = TArray<float>({ (float)(0.0) });
                for (int Idx = 0; Idx < SkeletonParameterArray->Num(); Idx += 6)
                {
                    double RX = (*SkeletonParameterArray)[Idx + 0]->AsNumber();
                    double RY = (*SkeletonParameterArray)[Idx + 1]->AsNumber();
                    double RZ = (*SkeletonParameterArray)[Idx + 2]->AsNumber();
                    double PX = (*SkeletonParameterArray)[Idx + 3]->AsNumber();
                    double PY = (*SkeletonParameterArray)[Idx + 4]->AsNumber();
                    double PZ = (*SkeletonParameterArray)[Idx + 5]->AsNumber();
                    FQuat LocalRotation = FQuat::MakeFromEuler(FVector(RX, RY, RZ));
                    FVector LocalPositions(PX, PY, PZ);
                    FrameData.Transforms.Add(FTransform(LocalRotation, LocalPositions));
#ifdef SAVEDATA
                    outfp << LocalRotation.Euler()[0] << " "
                        << LocalRotation.Euler()[1] << " "
                        << LocalRotation.Euler()[2] << " ";
                    outfp << LocalPositions.X << " "
                        << LocalPositions.Y << " "
                        << LocalPositions.Z << " ";
#endif // SAVEDATA
                }
            }

            TSharedPtr<FNeuronLiveLinkSource> Source = mSource.Pin();
            if (Source)
            {
                Source->PushTestStaticData(Subject, Static);
                Source->PushTestFrameData(Subject, Frame);
            }
        }
    }
}
#endif // MYMOCAPTEST

const FString FMocapAppClient::GetStatus()
{
    FString Status = TEXT("Offline");
    if (IsRunning())
    {
#ifdef MYMOCAPTEST
        Status = TEXT("Online");
#else
        if (App)
        {
            if (App->GetIsConnecting())
            {
                if (App->GetIsReadyToUse())
                {
                    Status = TEXT("Online");
                }
                else
                {
                    Status = TEXT("Online Connection Error");
                }
            }
        }
#endif // MYMOCAPTEST
    }
    return Status;
}

void FMocapAppClient::GetAllRigidBodyNames(TArray<FString>& NameArray)
{
    if (App)
    {
        App->GetAllRigidBodyNames(NameArray);
    }
}

bool FMocapAppClient::GetRigidBodyPose(const FString& RigidName, FVector& Position, FQuat& Rotation, int& Status, int& JointTag)
{
    if (App)
    {
        return App->GetRigidBodyPose(RigidName, Position, Rotation, Status, JointTag);
    }
    return false;
}

void FMocapAppClient::GetAllAvatarNames(TArray<FString>& NameArray)
{
    if (App)
    {
        App->GetAllAvatarNames(NameArray);
    }
}

bool FMocapAppClient::GetAvatarData(const FString& AvatarName, TArray<FVector>& LocalPositions, TArray<FRotator>& LocalRotations)
{
    if (App)
    {
        return App->GetAvatarData(AvatarName, LocalPositions, LocalRotations);
    }
    return false;
}

bool FMocapAppClient::GetAvatarStaticData(const FString& AvatarName, int& RootJointTag, TArray<FName>& BoneNames, TArray<int>& BoneParents, TArray<FVector>& DefaultLocalPositions)
{
    if (App)
    {
        return App->GetAvatarStaticData(AvatarName, RootJointTag, BoneNames, BoneParents, DefaultLocalPositions);
    }
    return false;
}
